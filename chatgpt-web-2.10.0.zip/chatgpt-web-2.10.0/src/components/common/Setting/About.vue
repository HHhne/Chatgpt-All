<script setup lang='ts'>
import axios from 'axios'
import { onMounted, ref } from 'vue'
import { NSpin } from 'naive-ui'
import { fetchChatConfig } from '@/api'
import pkg from '@/../package.json'

interface ConfigState {
  timeoutMs?: number
  reverseProxy?: string
  apiModel?: string
  socksProxy?: string
  balance?:number
}

const loading = ref(false)
const config = ref<ConfigState>()
const apiKey = ref('')
const balance = ref<string>()

async function fetchConfig() {
  try {
    const { data } = await fetchChatConfig<ConfigState>()
    config.value = data
  }
  catch (error) {
    console.log(`Error fetching chat config: ${error.message}`)
  }
}

onMounted(() => {
  fetchConfig()
})
</script>


<template>
  <div>
    <NSpin :show="loading">
      <div class="p-4 space-y-4">
        <h2 class="text-xl font-bold">
          Version - 999
        </h2>
        <div class="p-2 space-y-2 rounded-md bg-neutral-100 dark:bg-neutral-700">
          <p>本站公益性质，欢迎赞助API token。         &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a
              class="text-blue-600 dark:text-blue-500"
              href="http://www.hhhnee.top/"
              target="_blank"
            >
              备用站
            </a></p>
        </div>
        <p>{{ $t("setting.api") }}：{{ config?.apiModel ?? '-' }}</p>
        <!-- <p>{{ $t("setting.reverseProxy") }}：{{ config?.reverseProxy ?? '-' }}</p> -->
        <p>{{ $t("setting.timeout") }}：{{ config?.timeoutMs ?? '-'}}</p>
        <p>余额：{{ config?.balance ?? '-' }}$      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    <a
              class="text-blue-600 dark:text-blue-500"
              href="http://live.hhhnee.top/"
              target="_blank"
            >
             API TOKEN 余额批量查询           
            </a></p> 
        <div>
          <p v-if="balance">{{ balance }}</p>
          <p v-else></p>
        </div>
      </div>
    </NSpin>
  </div>
</template>