import{f as U,r as B,ax as zt,ay as kt,g as f,az as Re,aA as Rt,aB as oe,aC as Tt,k as W,i as c,aD as Pt,j as _,l as Oe,u as re,aE as Bt,n as D,aF as Wt,U as F,p as Ne,aG as ge,aH as Lt,T as At,v as It,x as De,aI as Et,t as jt,F as me,aJ as Ot,C as Nt,aK as Dt,aL as Ft,L as G,K as Ht,aM as Mt,aN as de,M as Ut,w as ce,af as fe,E as Vt,N as K,aO as Xt,aP as Gt,aQ as Te,aR as Pe,O as ne,aS as Yt,aT as Kt,aU as Jt,aV as qt,ak as Zt,W as Qt,aj as ea,Y as Q,Z as ue,a3 as h,a9 as P,ac as S,_ as y,at as be,ae as z,ar as N,as as M,ab as Z,aW as ta,ao as Be,a8 as se,ah as aa,a0 as Fe,aX as na,aY as sa,aZ as oa,a_ as ra}from"./index-b487f1bb.js";const ia=Re(".v-x-scroll",{overflow:"auto",scrollbarWidth:"none"},[Re("&::-webkit-scrollbar",{width:0,height:0})]),la=U({name:"XScroll",props:{disabled:Boolean,onScroll:Function},setup(){const e=B(null);function t(r){!(r.currentTarget.offsetWidth<r.currentTarget.scrollWidth)||r.deltaY===0||(r.currentTarget.scrollLeft+=r.deltaY+r.deltaX,r.preventDefault())}const s=zt();return ia.mount({id:"vueuc/x-scroll",head:!0,anchorMetaName:kt,ssr:s}),Object.assign({selfRef:e,handleWheel:t},{scrollTo(...r){var u;(u=e.value)===null||u===void 0||u.scrollTo(...r)}})},render(){return f("div",{ref:"selfRef",onScroll:this.onScroll,onWheel:this.disabled?void 0:this.handleWheel,class:"v-x-scroll"},this.$slots)}});var da=/\s/;function ca(e){for(var t=e.length;t--&&da.test(e.charAt(t)););return t}var fa=/^\s+/;function ua(e){return e&&e.slice(0,ca(e)+1).replace(fa,"")}var We=0/0,ba=/^[-+]0x[0-9a-f]+$/i,pa=/^0b[01]+$/i,va=/^0o[0-7]+$/i,ha=parseInt;function Le(e){if(typeof e=="number")return e;if(Rt(e))return We;if(oe(e)){var t=typeof e.valueOf=="function"?e.valueOf():e;e=oe(t)?t+"":t}if(typeof e!="string")return e===0?e:+e;e=ua(e);var s=pa.test(e);return s||va.test(e)?ha(e.slice(2),s?2:8):ba.test(e)?We:+e}var ga=function(){return Tt.Date.now()};const pe=ga;var ma="Expected a function",xa=Math.max,ya=Math.min;function wa(e,t,s){var l,r,u,i,d,m,$=0,k=!1,w=!1,x=!0;if(typeof e!="function")throw new TypeError(ma);t=Le(t)||0,oe(s)&&(k=!!s.leading,w="maxWait"in s,u=w?xa(Le(s.maxWait)||0,t):u,x="trailing"in s?!!s.trailing:x);function R(C){var A=l,V=r;return l=r=void 0,$=C,i=e.apply(V,A),i}function T(C){return $=C,d=setTimeout(E,t),k?R(C):i}function j(C){var A=C-m,V=C-$,Y=t-A;return w?ya(Y,u-V):Y}function L(C){var A=C-m,V=C-$;return m===void 0||A>=t||A<0||w&&V>=u}function E(){var C=pe();if(L(C))return o(C);d=setTimeout(E,j(C))}function o(C){return d=void 0,x&&l?R(C):(l=r=void 0,i)}function b(){d!==void 0&&clearTimeout(d),$=0,l=m=r=d=void 0}function g(){return d===void 0?i:o(pe())}function I(){var C=pe(),A=L(C);if(l=arguments,r=this,m=C,A){if(d===void 0)return T(m);if(w)return clearTimeout(d),d=setTimeout(E,t),R(m)}return d===void 0&&(d=setTimeout(E,t)),i}return I.cancel=b,I.flush=g,I}var Ca="Expected a function";function ve(e,t,s){var l=!0,r=!0;if(typeof e!="function")throw new TypeError(Ca);return oe(s)&&(l="leading"in s?!!s.leading:l,r="trailing"in s?!!s.trailing:r),wa(e,t,{leading:l,maxWait:t,trailing:r})}const $a=U({name:"Add",render(){return f("svg",{width:"512",height:"512",viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},f("path",{d:"M256 112V400M400 256H112",stroke:"currentColor","stroke-width":"32","stroke-linecap":"round","stroke-linejoin":"round"}))}}),_a=W([W("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),c("spin-container",{position:"relative"},[c("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[Pt()])]),c("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),c("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[_("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),c("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),c("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[_("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),Sa={small:20,medium:18,large:16},za=Object.assign(Object.assign({},re.props),{description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0}}),ka=U({name:"Spin",props:za,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:s}=Oe(e),l=re("Spin","-spin",_a,Bt,e,t),r=D(()=>{const{size:i}=e,{common:{cubicBezierEaseInOut:d},self:m}=l.value,{opacitySpinning:$,color:k,textColor:w}=m,x=typeof i=="number"?Wt(i):m[F("size",i)];return{"--n-bezier":d,"--n-opacity-spinning":$,"--n-size":x,"--n-color":k,"--n-text-color":w}}),u=s?Ne("spin",D(()=>{const{size:i}=e;return typeof i=="number"?String(i):i[0]}),r,e):void 0;return{mergedClsPrefix:t,compitableShow:ge(e,["spinning","show"]),mergedStrokeWidth:D(()=>{const{strokeWidth:i}=e;if(i!==void 0)return i;const{size:d}=e;return Sa[typeof d=="number"?"medium":d]}),cssVars:s?void 0:r,themeClass:u==null?void 0:u.themeClass,onRender:u==null?void 0:u.onRender}},render(){var e,t;const{$slots:s,mergedClsPrefix:l,description:r}=this,u=s.icon&&this.rotate,i=(r||s.description)&&f("div",{class:`${l}-spin-description`},r||((e=s.description)===null||e===void 0?void 0:e.call(s))),d=s.icon?f("div",{class:[`${l}-spin-body`,this.themeClass]},f("div",{class:[`${l}-spin`,u&&`${l}-spin--rotate`],style:s.default?"":this.cssVars},s.icon()),i):f("div",{class:[`${l}-spin-body`,this.themeClass]},f(Lt,{clsPrefix:l,style:s.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${l}-spin`}),i);return(t=this.onRender)===null||t===void 0||t.call(this),s.default?f("div",{class:[`${l}-spin-container`,this.themeClass],style:this.cssVars},f("div",{class:[`${l}-spin-content`,this.compitableShow&&`${l}-spin-content--spinning`]},s),f(At,{name:"fade-in-transition"},{default:()=>this.compitableShow?d:null})):d}}),ye=It("n-tabs"),He={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},Ae=U({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:He,setup(e){const t=De(ye,null);return t||Et("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:t.paneStyleRef,class:t.paneClassRef,mergedClsPrefix:t.mergedClsPrefixRef}},render(){return f("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Ra=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},Ft(He,["displayDirective"])),xe=U({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Ra,setup(e){const{mergedClsPrefixRef:t,valueRef:s,typeRef:l,closableRef:r,tabStyleRef:u,tabChangeIdRef:i,onBeforeLeaveRef:d,triggerRef:m,handleAdd:$,activateTab:k,handleClose:w}=De(ye);return{trigger:m,mergedClosable:D(()=>{if(e.internalAddable)return!1;const{closable:x}=e;return x===void 0?r.value:x}),style:u,clsPrefix:t,value:s,type:l,handleClose(x){x.stopPropagation(),!e.disabled&&w(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){$();return}const{name:x}=e,R=++i.id;if(x!==s.value){const{value:T}=d;T?Promise.resolve(T(e.name,s.value)).then(j=>{j&&i.id===R&&k(x)}):k(x)}}}},render(){const{internalAddable:e,clsPrefix:t,name:s,disabled:l,label:r,tab:u,value:i,mergedClosable:d,style:m,trigger:$,$slots:{default:k}}=this,w=r??u;return f("div",{class:`${t}-tabs-tab-wrapper`},this.internalLeftPadded?f("div",{class:`${t}-tabs-tab-pad`}):null,f("div",Object.assign({key:s,"data-name":s,"data-disabled":l?!0:void 0},jt({class:[`${t}-tabs-tab`,i===s&&`${t}-tabs-tab--active`,l&&`${t}-tabs-tab--disabled`,d&&`${t}-tabs-tab--closable`,e&&`${t}-tabs-tab--addable`],onClick:$==="click"?this.activateTab:void 0,onMouseenter:$==="hover"?this.activateTab:void 0,style:e?void 0:m},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),f("span",{class:`${t}-tabs-tab__label`},e?f(me,null,f("div",{class:`${t}-tabs-tab__height-placeholder`}," "),f(Ot,{clsPrefix:t},{default:()=>f($a,null)})):k?k():typeof w=="object"?w:Nt(w??s)),d&&this.type==="card"?f(Dt,{clsPrefix:t,class:`${t}-tabs-tab__close`,onClick:this.handleClose,disabled:l}):null))}}),Ta=c("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[_("segment-type",[c("tabs-rail",[W("&.transition-disabled","color: red;",[c("tabs-tab",`
 transition: none;
 `)])])]),_("left, right",`
 flex-direction: row;
 `,[c("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),c("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),_("right",`
 flex-direction: row-reverse;
 `,[c("tabs-bar",`
 left: 0;
 `)]),_("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[c("tabs-bar",`
 top: 0;
 `)]),c("tabs-rail",`
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[c("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[c("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[_("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 `),W("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),_("flex",[c("tabs-nav",{width:"100%"},[c("tabs-wrapper",{width:"100%"},[c("tabs-tab",{marginRight:0})])])]),c("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[G("prefix, suffix",`
 display: flex;
 align-items: center;
 `),G("prefix","padding-right: 16px;"),G("suffix","padding-left: 16px;")]),c("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[_("shadow-before",[W("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),_("shadow-after",[W("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),c("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[W("&::-webkit-scrollbar",`
 width: 0;
 height: 0;
 `)]),W("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 width: 20px;
 z-index: 1;
 `),W("&::before",`
 left: 0;
 `),W("&::after",`
 right: 0;
 `)]),c("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 width: fit-content;
 `),c("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),c("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),c("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[_("disabled",{cursor:"not-allowed"}),G("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),G("label",`
 display: flex;
 align-items: center;
 `)]),c("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[W("&.transition-disabled",`
 transition: none;
 `),_("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),c("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),c("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 padding: var(--n-pane-padding);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[W("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),W("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),W("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),W("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),W("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),c("tabs-tab-pad",`
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),_("line-type, bar-type",[c("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[W("&:hover",{color:"var(--n-tab-text-color-hover)"}),_("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),_("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),c("tabs-nav",[_("line-type",[G("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),c("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),c("tabs-bar",`
 border-radius: 0;
 bottom: -1px;
 `)]),_("card-type",[G("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),c("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),c("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),c("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[_("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 `,[G("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),Ht("disabled",[W("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),_("closable","padding-right: 6px;"),_("active",`
 border-bottom: 1px solid #0000;
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),_("disabled","color: var(--n-tab-text-color-disabled);")]),c("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);")]),_("left, right",[c("tabs-wrapper",`
 flex-direction: column;
 `,[c("tabs-tab-wrapper",`
 flex-direction: column;
 `,[c("tabs-tab-pad",`
 height: var(--n-tab-gap);
 width: 100%;
 `)])]),c("tabs-nav-scroll-content",`
 border-bottom: none;
 `)]),_("left",[c("tabs-nav-scroll-content",`
 box-sizing: border-box;
 border-right: 1px solid var(--n-tab-border-color);
 `)]),_("right",[c("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `)]),_("bottom",[c("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 border-bottom: none;
 `)])])]),Pa=Object.assign(Object.assign({},re.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],barWidth:Number,paneClass:String,paneStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),Ba=U({name:"Tabs",props:Pa,setup(e,{slots:t}){var s,l,r,u;const{mergedClsPrefixRef:i,inlineThemeDisabled:d}=Oe(e),m=re("Tabs","-tabs",Ta,Mt,e,i),$=B(null),k=B(null),w=B(null),x=B(null),R=B(null),T=B(!0),j=B(!0),L=ge(e,["labelSize","size"]),E=ge(e,["activeName","value"]),o=B((l=(s=E.value)!==null&&s!==void 0?s:e.defaultValue)!==null&&l!==void 0?l:t.default?(u=(r=de(t.default())[0])===null||r===void 0?void 0:r.props)===null||u===void 0?void 0:u.name:null),b=Ut(E,o),g={id:0},I=D(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});ce(b,()=>{g.id=0,Y(),we()});function C(){var a;const{value:n}=b;return n===null?null:(a=$.value)===null||a===void 0?void 0:a.querySelector(`[data-name="${n}"]`)}function A(a){if(e.type==="card")return;const{value:n}=k;if(n&&a){const p=`${i.value}-tabs-bar--disabled`,{barWidth:v,placement:H}=e;if(a.dataset.disabled==="true"?n.classList.add(p):n.classList.remove(p),["top","bottom"].includes(H)){if(V(["top","maxHeight","height"]),typeof v=="number"&&a.offsetWidth>=v){const O=Math.floor((a.offsetWidth-v)/2)+a.offsetLeft;n.style.left=`${O}px`,n.style.maxWidth=`${v}px`}else n.style.left=`${a.offsetLeft}px`,n.style.maxWidth=`${a.offsetWidth}px`;n.style.width="8192px",n.offsetWidth}else{if(V(["left","maxWidth","width"]),typeof v=="number"&&a.offsetHeight>=v){const O=Math.floor((a.offsetHeight-v)/2)+a.offsetTop;n.style.top=`${O}px`,n.style.maxHeight=`${v}px`}else n.style.top=`${a.offsetTop}px`,n.style.maxHeight=`${a.offsetHeight}px`;n.style.height="8192px",n.offsetHeight}}}function V(a){const{value:n}=k;if(n)for(const p of a)n.style[p]=""}function Y(){if(e.type==="card")return;const a=C();a&&A(a)}function we(a){var n;const p=(n=R.value)===null||n===void 0?void 0:n.$el;if(!p)return;const v=C();if(!v)return;const{scrollLeft:H,offsetWidth:O}=p,{offsetLeft:q,offsetWidth:ae}=v;H>q?p.scrollTo({top:0,left:q,behavior:"smooth"}):q+ae>H+O&&p.scrollTo({top:0,left:q+ae-O,behavior:"smooth"})}const ee=B(null);let ie=0,X=null;function Me(a){const n=ee.value;if(n){ie=a.getBoundingClientRect().height;const p=`${ie}px`,v=()=>{n.style.height=p,n.style.maxHeight=p};X?(v(),X(),X=null):X=v}}function Ue(a){const n=ee.value;if(n){const p=a.getBoundingClientRect().height,v=()=>{document.body.offsetHeight,n.style.maxHeight=`${p}px`,n.style.height=`${Math.max(ie,p)}px`};X?(X(),X=null,v()):X=v}}function Ve(){const a=ee.value;a&&(a.style.maxHeight="",a.style.height="")}const Ce={value:[]},$e=B("next");function Xe(a){const n=b.value;let p="next";for(const v of Ce.value){if(v===n)break;if(v===a){p="prev";break}}$e.value=p,Ge(a)}function Ge(a){const{onActiveNameChange:n,onUpdateValue:p,"onUpdate:value":v}=e;n&&ne(n,a),p&&ne(p,a),v&&ne(v,a),o.value=a}function Ye(a){const{onClose:n}=e;n&&ne(n,a)}function _e(){const{value:a}=k;if(!a)return;const n="transition-disabled";a.classList.add(n),Y(),a.classList.remove(n)}let Se=0;function Ke(a){var n;if(a.contentRect.width===0&&a.contentRect.height===0||Se===a.contentRect.width)return;Se=a.contentRect.width;const{type:p}=e;(p==="line"||p==="bar")&&_e(),p!=="segment"&&le((n=R.value)===null||n===void 0?void 0:n.$el)}const Je=ve(Ke,64);ce([()=>e.justifyContent,()=>e.size],()=>{fe(()=>{const{type:a}=e;(a==="line"||a==="bar")&&_e()})});const te=B(!1);function qe(a){var n;const{target:p,contentRect:{width:v}}=a,H=p.parentElement.offsetWidth;if(!te.value)H<v&&(te.value=!0);else{const{value:O}=x;if(!O)return;H-v>O.$el.offsetWidth&&(te.value=!1)}le((n=R.value)===null||n===void 0?void 0:n.$el)}const Ze=ve(qe,64);function Qe(){const{onAdd:a}=e;a&&a(),fe(()=>{const n=C(),{value:p}=R;!n||!p||p.scrollTo({left:n.offsetLeft,top:0,behavior:"smooth"})})}function le(a){if(!a)return;const{scrollLeft:n,scrollWidth:p,offsetWidth:v}=a;T.value=n<=0,j.value=n+v>=p}const et=ve(a=>{le(a.target)},64);Vt(ye,{triggerRef:K(e,"trigger"),tabStyleRef:K(e,"tabStyle"),paneClassRef:K(e,"paneClass"),paneStyleRef:K(e,"paneStyle"),mergedClsPrefixRef:i,typeRef:K(e,"type"),closableRef:K(e,"closable"),valueRef:b,tabChangeIdRef:g,onBeforeLeaveRef:K(e,"onBeforeLeave"),activateTab:Xe,handleClose:Ye,handleAdd:Qe}),Xt(()=>{Y(),we()}),Gt(()=>{const{value:a}=w;if(!a||["left","right"].includes(e.placement))return;const{value:n}=i,p=`${n}-tabs-nav-scroll-wrapper--shadow-before`,v=`${n}-tabs-nav-scroll-wrapper--shadow-after`;T.value?a.classList.remove(p):a.classList.add(p),j.value?a.classList.remove(v):a.classList.add(v)});const ze=B(null);ce(b,()=>{if(e.type==="segment"){const a=ze.value;a&&fe(()=>{a.classList.add("transition-disabled"),a.offsetWidth,a.classList.remove("transition-disabled")})}});const tt={syncBarPosition:()=>{Y()}},ke=D(()=>{const{value:a}=L,{type:n}=e,p={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[n],v=`${a}${p}`,{self:{barColor:H,closeIconColor:O,closeIconColorHover:q,closeIconColorPressed:ae,tabColor:at,tabBorderColor:nt,paneTextColor:st,tabFontWeight:ot,tabBorderRadius:rt,tabFontWeightActive:it,colorSegment:lt,fontWeightStrong:dt,tabColorSegment:ct,closeSize:ft,closeIconSize:ut,closeColorHover:bt,closeColorPressed:pt,closeBorderRadius:vt,[F("panePadding",a)]:ht,[F("tabPadding",v)]:gt,[F("tabPaddingVertical",v)]:mt,[F("tabGap",v)]:xt,[F("tabTextColor",n)]:yt,[F("tabTextColorActive",n)]:wt,[F("tabTextColorHover",n)]:Ct,[F("tabTextColorDisabled",n)]:$t,[F("tabFontSize",a)]:_t},common:{cubicBezierEaseInOut:St}}=m.value;return{"--n-bezier":St,"--n-color-segment":lt,"--n-bar-color":H,"--n-tab-font-size":_t,"--n-tab-text-color":yt,"--n-tab-text-color-active":wt,"--n-tab-text-color-disabled":$t,"--n-tab-text-color-hover":Ct,"--n-pane-text-color":st,"--n-tab-border-color":nt,"--n-tab-border-radius":rt,"--n-close-size":ft,"--n-close-icon-size":ut,"--n-close-color-hover":bt,"--n-close-color-pressed":pt,"--n-close-border-radius":vt,"--n-close-icon-color":O,"--n-close-icon-color-hover":q,"--n-close-icon-color-pressed":ae,"--n-tab-color":at,"--n-tab-font-weight":ot,"--n-tab-font-weight-active":it,"--n-tab-padding":gt,"--n-tab-padding-vertical":mt,"--n-tab-gap":xt,"--n-pane-padding":ht,"--n-font-weight-strong":dt,"--n-tab-color-segment":ct}}),J=d?Ne("tabs",D(()=>`${L.value[0]}${e.type[0]}`),ke,e):void 0;return Object.assign({mergedClsPrefix:i,mergedValue:b,renderedNames:new Set,tabsRailElRef:ze,tabsPaneWrapperRef:ee,tabsElRef:$,barElRef:k,addTabInstRef:x,xScrollInstRef:R,scrollWrapperElRef:w,addTabFixed:te,tabWrapperStyle:I,handleNavResize:Je,mergedSize:L,handleScroll:et,handleTabsResize:Ze,cssVars:d?void 0:ke,themeClass:J==null?void 0:J.themeClass,animationDirection:$e,renderNameListRef:Ce,onAnimationBeforeLeave:Me,onAnimationEnter:Ue,onAnimationAfterEnter:Ve,onRender:J==null?void 0:J.onRender},tt)},render(){const{mergedClsPrefix:e,type:t,placement:s,addTabFixed:l,addable:r,mergedSize:u,renderNameListRef:i,onRender:d,$slots:{default:m,prefix:$,suffix:k}}=this;d==null||d();const w=m?de(m()).filter(o=>o.type.__TAB_PANE__===!0):[],x=m?de(m()).filter(o=>o.type.__TAB__===!0):[],R=!x.length,T=t==="card",j=t==="segment",L=!T&&!j&&this.justifyContent;i.value=[];const E=()=>{const o=f("div",{style:this.tabWrapperStyle,class:[`${e}-tabs-wrapper`]},L?null:f("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}),R?w.map((b,g)=>(i.value.push(b.props.name),he(f(xe,Object.assign({},b.props,{internalCreatedByPane:!0,internalLeftPadded:g!==0&&(!L||L==="center"||L==="start"||L==="end")}),b.children?{default:b.children.tab}:void 0)))):x.map((b,g)=>(i.value.push(b.props.name),he(g!==0&&!L?je(b):b))),!l&&r&&T?Ee(r,(R?w.length:x.length)!==0):null,L?null:f("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return f("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},T&&r?f(Pe,{onResize:this.handleTabsResize},{default:()=>o}):o,T?f("div",{class:`${e}-tabs-pad`}):null,T?null:f("div",{ref:"barElRef",class:`${e}-tabs-bar`}))};return f("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${t}-type`,`${e}-tabs--${u}-size`,L&&`${e}-tabs--flex`,`${e}-tabs--${s}`],style:this.cssVars},f("div",{class:[`${e}-tabs-nav--${t}-type`,`${e}-tabs-nav--${s}`,`${e}-tabs-nav`]},Te($,o=>o&&f("div",{class:`${e}-tabs-nav__prefix`},o)),j?f("div",{class:`${e}-tabs-rail`,ref:"tabsRailElRef"},R?w.map((o,b)=>(i.value.push(o.props.name),f(xe,Object.assign({},o.props,{internalCreatedByPane:!0,internalLeftPadded:b!==0}),o.children?{default:o.children.tab}:void 0))):x.map((o,b)=>(i.value.push(o.props.name),b===0?o:je(o)))):f(Pe,{onResize:this.handleNavResize},{default:()=>f("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(s)?f(la,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:E}):f("div",{class:`${e}-tabs-nav-y-scroll`},E()))}),l&&r&&T?Ee(r,!0):null,Te(k,o=>o&&f("div",{class:`${e}-tabs-nav__suffix`},o))),R&&(this.animated?f("div",{ref:"tabsPaneWrapperRef",class:`${e}-tabs-pane-wrapper`},Ie(w,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):Ie(w,this.mergedValue,this.renderedNames)))}});function Ie(e,t,s,l,r,u,i){const d=[];return e.forEach(m=>{const{name:$,displayDirective:k,"display-directive":w}=m.props,x=T=>k===T||w===T,R=t===$;if(m.key!==void 0&&(m.key=$),R||x("show")||x("show:lazy")&&s.has($)){s.has($)||s.add($);const T=!x("if");d.push(T?Yt(m,[[Kt,R]]):m)}}),i?f(Jt,{name:`${i}-transition`,onBeforeLeave:l,onEnter:r,onAfterEnter:u},{default:()=>d}):d}function Ee(e,t){return f(xe,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:t,disabled:typeof e=="object"&&e.disabled})}function je(e){const t=qt(e);return t.props?t.props.internalLeftPadded=!0:t.props={internalLeftPadded:!0},t}function he(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}function Wa(){const e=new Date,t=e.getDate(),s=e.getMonth()+1;return`${e.getFullYear()}-${s}-${t}`}const La={class:"p-4 space-y-5 min-h-[200px]"},Aa={class:"space-y-6"},Ia={class:"flex items-center space-x-4"},Ea={class:"flex-shrink-0 w-[100px]"},ja={class:"flex-1"},Oa={class:"flex items-center space-x-4"},Na={class:"flex-shrink-0 w-[100px]"},Da={class:"w-[200px]"},Fa={class:"flex items-center space-x-4"},Ha={class:"flex-shrink-0 w-[100px]"},Ma={class:"flex-1"},Ua={class:"flex items-center space-x-4"},Va={class:"flex-shrink-0 w-[100px]"},Xa={class:"flex flex-wrap items-center gap-4"},Ga={class:"flex items-center space-x-4"},Ya={class:"flex-shrink-0 w-[100px]"},Ka={class:"flex flex-wrap items-center gap-4"},Ja={class:"flex items-center space-x-4"},qa={class:"flex-shrink-0 w-[100px]"},Za={class:"flex flex-wrap items-center gap-4"},Qa={class:"flex items-center space-x-4"},en={class:"flex-shrink-0 w-[100px]"},tn=U({__name:"General",setup(e){const t=Zt(),s=Qt(),l=ea(),r=D(()=>t.theme),u=D(()=>s.userInfo),i=B(u.value.avatar??""),d=B(u.value.name??""),m=B(u.value.description??""),$=D({get(){return t.language},set(o){t.setLanguage(o)}}),k=[{label:"Auto",key:"auto",icon:"ri:contrast-line"},{label:"Light",key:"light",icon:"ri:sun-foggy-line"},{label:"Dark",key:"dark",icon:"ri:moon-foggy-line"}],w=[{label:"简体中文",key:"zh-CN",value:"zh-CN"},{label:"繁體中文",key:"zh-TW",value:"zh-TW"},{label:"English",key:"en-US",value:"en-US"}];function x(o){s.updateUserInfo(o),l.success(se("common.success"))}function R(){s.resetUserInfo(),l.success(se("common.success")),window.location.reload()}function T(){const o=Wa(),b=localStorage.getItem("chatStorage")||"{}",g=JSON.stringify(JSON.parse(b),null,2),I=new Blob([g],{type:"application/json"}),C=URL.createObjectURL(I),A=document.createElement("a");A.href=C,A.download=`chat-store_${o}.json`,document.body.appendChild(A),A.click(),document.body.removeChild(A)}function j(o){const b=o.target;if(!b||!b.files)return;const g=b.files[0];if(!g)return;const I=new FileReader;I.onload=()=>{try{const C=JSON.parse(I.result);localStorage.setItem("chatStorage",JSON.stringify(C)),l.success(se("common.success")),location.reload()}catch{l.error(se("common.invalidFileFormat"))}},I.readAsText(g)}function L(){localStorage.removeItem("chatStorage"),location.reload()}function E(){const o=document.getElementById("fileInput");o&&o.click()}return(o,b)=>(Q(),ue("div",La,[h("div",Aa,[h("div",Ia,[h("span",Ea,P(o.$t("setting.avatarLink")),1),h("div",ja,[S(y(be),{value:i.value,"onUpdate:value":b[0]||(b[0]=g=>i.value=g),placeholder:""},null,8,["value"])]),S(y(M),{size:"tiny",text:"",type:"primary",onClick:b[1]||(b[1]=g=>x({avatar:i.value}))},{default:z(()=>[N(P(o.$t("common.save")),1)]),_:1})]),h("div",Oa,[h("span",Na,P(o.$t("setting.name")),1),h("div",Da,[S(y(be),{value:d.value,"onUpdate:value":b[2]||(b[2]=g=>d.value=g),placeholder:""},null,8,["value"])]),S(y(M),{size:"tiny",text:"",type:"primary",onClick:b[3]||(b[3]=g=>x({name:d.value}))},{default:z(()=>[N(P(o.$t("common.save")),1)]),_:1})]),h("div",Fa,[h("span",Ha,P(o.$t("setting.description")),1),h("div",Ma,[S(y(be),{value:m.value,"onUpdate:value":b[4]||(b[4]=g=>m.value=g),placeholder:""},null,8,["value"])]),S(y(M),{size:"tiny",text:"",type:"primary",onClick:b[5]||(b[5]=g=>x({description:m.value}))},{default:z(()=>[N(P(o.$t("common.save")),1)]),_:1})]),h("div",Ua,[h("span",Va,P(o.$t("setting.chatHistory")),1),h("div",Xa,[S(y(M),{size:"small",onClick:T},{icon:z(()=>[S(y(Z),{icon:"ri:download-2-fill"})]),default:z(()=>[N(" "+P(o.$t("common.export")),1)]),_:1}),h("input",{id:"fileInput",type:"file",style:{display:"none"},onChange:j},null,32),S(y(M),{size:"small",onClick:E},{icon:z(()=>[S(y(Z),{icon:"ri:upload-2-fill"})]),default:z(()=>[N(" "+P(o.$t("common.import")),1)]),_:1}),S(y(ta),{placement:"bottom",onPositiveClick:L},{trigger:z(()=>[S(y(M),{size:"small"},{icon:z(()=>[S(y(Z),{icon:"ri:close-circle-line"})]),default:z(()=>[N(" "+P(o.$t("common.clear")),1)]),_:1})]),default:z(()=>[N(" "+P(o.$t("chat.clearHistoryConfirm")),1)]),_:1})])]),h("div",Ga,[h("span",Ya,P(o.$t("setting.theme")),1),h("div",Ka,[(Q(),ue(me,null,Be(k,g=>S(y(M),{key:g.key,size:"small",type:g.key===y(r)?"primary":void 0,onClick:I=>y(t).setTheme(g.key)},{icon:z(()=>[S(y(Z),{icon:g.icon},null,8,["icon"])]),_:2},1032,["type","onClick"])),64))])]),h("div",Ja,[h("span",qa,P(o.$t("setting.language")),1),h("div",Za,[(Q(),ue(me,null,Be(w,g=>S(y(M),{key:g.key,size:"small",type:g.key===y($)?"primary":void 0,onClick:I=>y(t).setLanguage(g.key)},{default:z(()=>[N(P(g.label),1)]),_:2},1032,["type","onClick"])),64))])]),h("div",Qa,[h("span",en,P(o.$t("setting.resetUserInfo")),1),S(y(M),{size:"small",onClick:R},{default:z(()=>[N(P(o.$t("common.reset")),1)]),_:1})])])]))}}),an={class:"p-4 space-y-4"},nn=h("h2",{class:"text-xl font-bold"}," Version - 999 ",-1),sn=h("div",{class:"p-2 space-y-2 rounded-md bg-neutral-100 dark:bg-neutral-700"},[h("p",null,[N("本站公益性质，欢迎赞助API token。                                                             "),h("a",{class:"text-blue-600 dark:text-blue-500",href:"http://www.hhhnee.top/",target:"_blank"}," 备用站 ")]),h("img",{src:"https://raw.githubusercontent.com/HHhne/Chatgpt-All/main/images/xx.jpg",alt:"Image description"})],-1),on=h("a",{class:"text-blue-600 dark:text-blue-500",href:"http://live.hhhnee.top/",target:"_blank"}," API TOKEN 余额批量查询 ",-1),rn=U({__name:"About",setup(e){const t=B(!1),s=B();async function l(){try{t.value=!0;const{data:r}=await na();s.value=r}finally{t.value=!1}}return aa(()=>{l()}),(r,u)=>(Q(),Fe(y(ka),{show:t.value},{default:z(()=>{var i,d;return[h("div",an,[nn,sn,h("p",null,P(r.$t("setting.api"))+"："+P(((i=s.value)==null?void 0:i.apiModel)??"-"),1),h("p",null,[N("余额："+P(((d=s.value)==null?void 0:d.balance)??"-")+"$                                                                   ",1),on])])]}),_:1},8,["show"]))}}),ln={class:"ml-2"},dn={class:"min-h-[100px]"},cn={class:"ml-2"},un=U({__name:"index",props:{visible:{type:Boolean}},emits:["update:visible"],setup(e,{emit:t}){const s=e,l=B("General"),r=D({get(){return s.visible},set(u){t("update:visible",u)}});return(u,i)=>(Q(),Fe(y(ra),{show:y(r),"onUpdate:show":i[1]||(i[1]=d=>oa(r)?r.value=d:null),"auto-focus":!1},{default:z(()=>[S(y(sa),{role:"dialog","aria-modal":"true",bordered:!1,style:{width:"95%","max-width":"640px"}},{default:z(()=>[S(y(Ba),{value:l.value,"onUpdate:value":i[0]||(i[0]=d=>l.value=d),type:"line",animated:""},{default:z(()=>[S(y(Ae),{name:"General",tab:"General"},{tab:z(()=>[S(y(Z),{class:"text-lg",icon:"ri:file-user-line"}),h("span",ln,P(u.$t("setting.general")),1)]),default:z(()=>[h("div",dn,[S(tn)])]),_:1}),S(y(Ae),{name:"Config",tab:"Config"},{tab:z(()=>[S(y(Z),{class:"text-lg",icon:"ri:list-settings-line"}),h("span",cn,P(u.$t("setting.config")),1)]),default:z(()=>[S(rn)]),_:1})]),_:1},8,["value"])]),_:1})]),_:1},8,["show"]))}});export{un as default};
